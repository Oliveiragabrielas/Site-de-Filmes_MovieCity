import { useState } from "react";
import afterlife from "../assets/afterlife.jpg";
import transformers from "../assets/transformers.jpg";
import mowgli from "../assets/mowgli.jpg";
import shift from "../assets/shift.png";
import squidgame from "../assets/squidgame.webp";
import harrypotter from "../assets/harrypotter.jpg";

const movies = [
  { title: "Afterlife", image: afterlife },
  { title: "Transformers", image: transformers },
  { title: "Mowgli", image: mowgli },
  { title: "Shift", image: shift },
  { title: "Round 6", image: squidgame },
  { title: "Harry Potter", image: harrypotter },
];

export default function Main() {
  const [showAll, setShowAll] = useState(false);

  return (
    <main className="main-content" id="inicio">
      <section className="intro" id="sobre">
        <p className="eyebrow">SEU PRÓXIMO FILME ESTÁ AQUI</p>
        <h1>Seus Filmes</h1>
        <p className="description">
          Aqui, você pode escolher o filme que deseja assistir.
          Caso queira escolher mais, clique no botão.
        </p>
        <button className="button more-button" onClick={() => setShowAll(!showAll)}>
          {showAll ? "Mostrar menos" : "Mais"}
        </button>
        {showAll && (
          <p className="extra-text" id="categoria">
            Explore nossa seleção e encontre uma história para cada momento.
          </p>
        )}
      </section>

      <section className="movie-section" id="filmes" aria-label="Filmes em destaque">
        <div className="movie-grid">
          {movies.map((movie) => (
            <article className="movie-card" key={movie.title}>
              <img src={movie.image} alt={`Imagem do filme ${movie.title}`} />
              <div className="movie-overlay">
                <h2>{movie.title}</h2>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
