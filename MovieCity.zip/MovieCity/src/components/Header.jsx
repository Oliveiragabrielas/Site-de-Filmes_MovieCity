import { useState } from "react";

const links = [
  { label: "Filmes", href: "#filmes" },
  { label: "Categoria", href: "#categoria" },
  { label: "Sobre", href: "#sobre" },
  { label: "Contato", href: "#contato" },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  function closeMenu() {
    setMenuOpen(false);
  }

  return (
    <header className="header">
      <a className="logo" href="#inicio" aria-label="MovieCity - início">
        MovieCity
      </a>

      <button
        className="menu-toggle"
        type="button"
        aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
        aria-expanded={menuOpen}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav className={`navigation ${menuOpen ? "open" : ""}`} aria-label="Navegação principal">
        {links.map((link) => (
          <a key={link.label} href={link.href} onClick={closeMenu}>
            {link.label}
          </a>
        ))}
        <a className="login-mobile" href="#login" onClick={closeMenu}>Login</a>
      </nav>

      <a className="button login-button" href="#login">Login</a>
    </header>
  );
}
