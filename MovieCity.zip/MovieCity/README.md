# 🎬 MovieCity — Landing Page

Landing page responsiva de um serviço de streaming fictício, desenvolvida como atividade prática com **React + Vite**.

## ✨ Funcionalidades

- Cabeçalho com navegação e botão de Login.
- Grade com seis filmes e imagens locais.
- Botão “Mais” com conteúdo adicional.
- Menu hambúrguer para telas pequenas.
- Layout responsivo para computador, tablet e celular.

## 🛠️ Tecnologias

- React
- Vite
- JavaScript
- CSS puro

## 🚀 Como executar

É necessário ter o Node.js instalado.

```bash
npm install
npm run dev
```

Depois, abra no navegador o endereço exibido no terminal (normalmente `http://localhost:5173`).

Para testar a versão de produção:

```bash
npm run build
npm run preview
```

## 📁 Estrutura do projeto

```text
MovieCity/
├── public/
├── src/
│   ├── assets/
│   ├── components/
│   │   ├── Header.jsx
│   │   ├── Home.jsx
│   │   └── Main.jsx
│   ├── main.jsx
│   └── style.css
├── index.html
├── package.json
└── README.md
```

## 🧪 Testes realizados

- Verificação da estrutura dos componentes.
- Imagens carregadas a partir de `src/assets`.
- Layout adaptado para telas menores.
- Menu mobile com abertura e fechamento.
- Botão “Mais” com alternância de conteúdo.

## 👩‍💻 Autoria

**Gabriela de Oliveira**  
Curso Técnico em Desenvolvimento de Sistemas — SENAI A. Jacob Lafer  
Ano: 2026
